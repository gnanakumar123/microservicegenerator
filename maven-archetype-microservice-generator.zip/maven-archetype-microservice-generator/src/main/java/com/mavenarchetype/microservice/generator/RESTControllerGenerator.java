package com.mavenarchetype.microservice.generator;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;

import org.springframework.stereotype.Component;

import com.mavenarchetype.microservice.request.pojos.ApiContract;
import com.mavenarchetype.microservice.request.pojos.MicroserviceGeneratorRequest;
import com.mavenarchetype.microservice.request.pojos.Parameter;
import com.mavenarchetype.microservice.request.pojos.Query1;
import com.mavenarchetype.microservice.request.pojos.ReturnVal;
import com.mavenarchetype.microservice.utility.Utility;

@Component
public class RESTControllerGenerator {

	public void generateControllerForDomain(String outputDirectory, String domainName,
			MicroserviceGeneratorRequest microServiceJsonPojo) throws UnableToDetermineMethodTypeException {

		StringBuffer strBuff = new StringBuffer();

		addImportAndClassDeclarationForController(domainName, strBuff);

		// getting command method info.
		// JSONArray commandArray = (JSONArray) jsonObject.get("commands");

		ArrayList<ApiContract> commandArray = microServiceJsonPojo.getApiContracts();
		System.out.println("apiContractsArray: " + commandArray);

		// getting queries method info.
		// JSONArray queriesArray = (JSONArray) jsonObject.get("queries");
		// ArrayList<Query1> queriesArray = microServiceJsonPojo.getQueries();
		// System.out.println("queriesArray: " + queriesArray);

		// generate command methods
		generateMethodsForCommand(commandArray, strBuff, domainName);

		// generate quert methods
		// generateMethodsForQuery(queriesArray, strBuff, domainName);

		strBuff.append("\n");
		strBuff.append("}");
		System.out.println(strBuff.toString());

		// String controllerFileName =
		// "C:\\Gnana\\kubernetes_learning\\maven_archetype\\dir_mvn_generation\\" +
		// domainName
		// + "Controller.java";

		String controllerFileLocation = outputDirectory + domainName + File.separator + "src" + File.separator + "main"
				+ File.separator + "java" + File.separator + "com" + File.separator + "domain" + File.separator
				+ domainName + File.separator + "controller" + File.separator + domainName + "Controller.java";

		Utility.writeToJavaFile(strBuff, controllerFileLocation);

	}

	private void addImportAndClassDeclarationForController(String domainName, StringBuffer strBuff) {
		strBuff.append("package com.domain." + domainName + "." + "controller;");
		strBuff.append("\n\n");
		strBuff.append("import org.springframework.beans.factory.annotation.Autowired;");
		strBuff.append("\n");
		strBuff.append("import org.springframework.web.bind.annotation.DeleteMapping;");
		strBuff.append("\n");
		strBuff.append("import org.springframework.web.bind.annotation.GetMapping;");
		strBuff.append("\n");
		strBuff.append("import org.springframework.web.bind.annotation.PathVariable;");
		strBuff.append("\n");
		strBuff.append("import org.springframework.web.bind.annotation.PathVariable;");
		strBuff.append("\n");
		strBuff.append("import org.springframework.web.bind.annotation.PostMapping;");
		strBuff.append("\n");
		strBuff.append("import org.springframework.web.bind.annotation.PutMapping;");
		strBuff.append("\n");
		strBuff.append("import org.springframework.web.bind.annotation.RequestBody;");
		strBuff.append("\n");
		strBuff.append("import org.springframework.web.bind.annotation.RequestMapping;");
		strBuff.append("\n");
		strBuff.append("import org.springframework.web.bind.annotation.RestController;");
		strBuff.append("\n");
		strBuff.append("import com.domain." + domainName + ".model." + domainName + ";");
		strBuff.append("\n");
		strBuff.append("import com.domain." + domainName + ".service." + domainName + "Service;");
		strBuff.append("\n");

		strBuff.append("\n@RestController");
		strBuff.append("\n");
		strBuff.append("@RequestMapping(\"/api\")");
		strBuff.append("\n");
		strBuff.append("public class " + domainName + "Controller {");
		strBuff.append("\n\n");
		strBuff.append("@Autowired");
		strBuff.append("\n");
		strBuff.append("private " + domainName + "Service service;");
		strBuff.append("\n\n");
	}

	private void generateMethodsForCommand(ArrayList<ApiContract> commandArray, StringBuffer strBuff, String domainName)
			throws UnableToDetermineMethodTypeException {
		Iterator<ApiContract> commandAndQueryIterator = commandArray.iterator();
		StringBuffer methodParamsStringBuffer = null;
		while (commandAndQueryIterator.hasNext()) {

			methodParamsStringBuffer = new StringBuffer();

			ApiContract apiContract = (ApiContract) commandAndQueryIterator.next();
			System.out.println(apiContract);

			String methodName = (String) apiContract.getMethodName();
			String methodType = (String) apiContract.getMethodType();
			String sql = (String) apiContract.getSQL();

			System.out.println("methodType ::" + methodType);
			System.out.println("methodName ::" + methodName);
			System.out.println("sql ::" + sql);

			String methodAnnotation = generateAnnotations(methodType, methodName, sql, domainName);

			ArrayList<Parameter> parametersArray = apiContract.getParameters();
			Iterator<Parameter> parametersIterator = parametersArray.iterator();

			while (parametersIterator.hasNext()) {

				Parameter parameterJsonObject = (Parameter) parametersIterator.next();
				String paramType = (String) parameterJsonObject.getType();
				String paramName = (String) parameterJsonObject.getName();

				System.out.println(paramType + " " + paramName);

				methodParamsStringBuffer.append("@PathVariable " + paramType + " " + paramName);
				if (parametersIterator.hasNext()) {
					methodParamsStringBuffer.append(",");
				}

			}

			String returnType = "";
			String returnName = "";

			if (apiContract.getReturnVal() != null) {

				ReturnVal returnObject = (ReturnVal) apiContract.getReturnVal();

				returnType = (String) returnObject.getType();
				returnName = (String) returnObject.getName();

			}

			System.out.println("returnType :: " + returnType + " " + returnName);

			// generate annotations
			strBuff.append(methodAnnotation);
			strBuff.append("\n");

			if (apiContract.getReturnVal() == null) {

				strBuff.append("\tpublic " + "void" + " " + methodName + "(");
				strBuff.append(methodParamsStringBuffer.toString());

				strBuff.append("){");
				strBuff.append("\n\n");
			} else {

				strBuff.append("\tpublic " + returnType + " " + methodName + "(");
				strBuff.append(methodParamsStringBuffer.toString());

				strBuff.append("){");
				strBuff.append("\n\n");

				strBuff.append("\t" + returnType + " " + returnName + " = null;");

			}

			if (apiContract.getReturnVal() != null) {

				strBuff.append("\n\treturn " + returnName + ";");
				strBuff.append("\n");
			}

			strBuff.append("\t}\n\n");

		}
	}

	/*
	 * private void generateMethodsForQuery(ArrayList<Query1> queryArray,
	 * StringBuffer strBuff, String domainName) throws
	 * UnableToDetermineMethodTypeException {
	 * 
	 * Iterator<Query1> queryIterator = queryArray.iterator(); StringBuffer
	 * methodParamsStringBuffer = null;
	 * 
	 * while (queryIterator.hasNext()) {
	 * 
	 * methodParamsStringBuffer = new StringBuffer();
	 * 
	 * Query1 queryJsonObject = (Query1) queryIterator.next();
	 * System.out.println(queryJsonObject);
	 * 
	 * String methodType = (String) queryJsonObject.getMethodType(); String
	 * methodName = (String) queryJsonObject.getMethodName();
	 * System.out.println("methodName ::" + methodName);
	 * 
	 * String methodAnnotation = generateAnnotations(methodType,methodName,
	 * domainName);
	 * 
	 * ArrayList<Parameter> parametersArray = queryJsonObject.getParameters();
	 * Iterator<Parameter> parametersIterator = parametersArray.iterator(); while
	 * (parametersIterator.hasNext()) {
	 * 
	 * Parameter parameterJsonObject = (Parameter) parametersIterator.next(); String
	 * paramType = (String) parameterJsonObject.getType(); String paramName =
	 * (String) parameterJsonObject.getName();
	 * 
	 * System.out.println(paramType + " " + paramName);
	 * 
	 * methodParamsStringBuffer.append("@PathVariable " + paramType + " " +
	 * paramName); if (parametersIterator.hasNext()) {
	 * methodParamsStringBuffer.append(","); }
	 * 
	 * }
	 * 
	 * String returnType = ""; String returnName = "";
	 * 
	 * if (queryJsonObject.getReturnVal() != null) {
	 * 
	 * ReturnVal returnObject = (ReturnVal) queryJsonObject.getReturnVal();
	 * 
	 * returnType = (String) returnObject.getType(); returnName = (String)
	 * returnObject.getName();
	 * 
	 * }
	 * 
	 * System.out.println("returnType :: " + returnType + " " + returnName);
	 * 
	 * // generate annotations strBuff.append(methodAnnotation);
	 * strBuff.append("\n");
	 * 
	 * if (queryJsonObject.getReturnVal() == null) {
	 * 
	 * strBuff.append("\tpublic " + "void" + " " + methodName + "(");
	 * strBuff.append(methodParamsStringBuffer.toString());
	 * 
	 * strBuff.append("){"); strBuff.append("\n\n"); } else {
	 * 
	 * strBuff.append("\tpublic " + returnType + " " + methodName + "(");
	 * strBuff.append(methodParamsStringBuffer.toString());
	 * 
	 * strBuff.append("){"); strBuff.append("\n\n");
	 * 
	 * strBuff.append("\t" + returnType + " " + returnName + " = null;");
	 * 
	 * }
	 * 
	 * if (queryJsonObject.getReturnVal() != null) {
	 * 
	 * strBuff.append("\n\treturn " + returnName + ";"); strBuff.append("\n"); }
	 * 
	 * strBuff.append("\t}\n\n");
	 * 
	 * } }
	 * 
	 */

	private String generateAnnotations(String methodType, String methodName, String sql, String domainName)
			throws UnableToDetermineMethodTypeException {

		String annotationString = "";

		if (methodType.toUpperCase().contains("GET") ||
			methodName.toLowerCase().contains("get") || 
			methodName.toLowerCase().contains("retrieve") || 
			methodName.toLowerCase().contains("find") || 
			methodName.toLowerCase().contains("search") || 
			sql != null && sql.toLowerCase().contains("select")
		   ) {
			annotationString = "\t@GetMapping(\"/" + domainName + "/{Id}\")";
		} else if (methodType.toUpperCase().contains("POST") || 
				   methodName.toLowerCase().contains("add") || 
				   methodName.toLowerCase().contains("save") || 
				   methodName.toLowerCase().contains("post") || 
				   methodName.toLowerCase().contains("insert") || 
				   sql != null && sql.toLowerCase().contains("insert")
				  ) {
			annotationString = "\t@PostMapping(\"/" + domainName + "\")";
		} else if (methodType.toUpperCase().contains("UPDATE") || 
				   methodName.toLowerCase().contains("update") || 
				   methodName.toLowerCase().contains("put") || 
				   sql != null && sql.toLowerCase().contains("update")
				   ) {
			annotationString = "\t@PutMapping(\"/" + domainName + "\")";
		} else if (methodType.toUpperCase().contains("DELETE") || 
				   methodName.toLowerCase().contains("delete") || 
				   methodName.toLowerCase().contains("remove") || 
				   sql != null && sql.toLowerCase().contains("delete")
				   ) {
			annotationString = "\t@DeleteMapping(\"/" + domainName + "/{Id}\")";
		} else {
			
			System.out.println("methodType ::"+methodType);
			System.out.println("methodName ::"+methodName);
			System.out.println("sql ::"+sql);

			throw new UnableToDetermineMethodTypeException(
					"Error : Could not derive method type as either Method Type is not passed or could not interpret from methodname"+methodType+" :: "+methodName);
		}

		return annotationString;
	}

}
