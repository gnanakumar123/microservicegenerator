package com.mavenarchetype.microservice.utility;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

public class Utility {

	public static void writeToJavaFile(StringBuffer strBuff, String controllerFileLocation) {
		FileWriter fw1 = null;

		try {

			fw1 = new FileWriter(new File(controllerFileLocation), StandardCharsets.UTF_8);

			fw1.write(strBuff.toString());

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				fw1.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
