package com.mavenarchetype.microservice.request.pojos;

import java.util.ArrayList;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class MicroserviceGeneratorRequest {

	public String name;
	public String description;
	public String capabilities;
	public String domainName;
	public String outputDirectory;
	public ArrayList<ApiContract> apiContracts;
	//public ArrayList<Query1> queries;
	public ArrayList<Dependency> dependencies;
}
