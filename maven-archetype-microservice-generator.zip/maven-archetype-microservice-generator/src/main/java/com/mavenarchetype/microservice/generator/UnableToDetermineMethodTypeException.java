package com.mavenarchetype.microservice.generator;

public class UnableToDetermineMethodTypeException extends Exception {
	
	public UnableToDetermineMethodTypeException(String errorMessage) {
        super(errorMessage);
    }

}
