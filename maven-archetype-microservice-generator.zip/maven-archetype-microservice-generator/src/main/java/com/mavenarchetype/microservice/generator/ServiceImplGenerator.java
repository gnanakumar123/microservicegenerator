package com.mavenarchetype.microservice.generator;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;

import org.springframework.stereotype.Component;

import com.mavenarchetype.microservice.request.pojos.ApiContract;
import com.mavenarchetype.microservice.request.pojos.MicroserviceGeneratorRequest;
import com.mavenarchetype.microservice.request.pojos.Parameter;
import com.mavenarchetype.microservice.request.pojos.Query1;
import com.mavenarchetype.microservice.request.pojos.ReturnVal;
import com.mavenarchetype.microservice.utility.Utility;

@Component
public class ServiceImplGenerator {

	public void generateServiceImplForDomain(String outputDirectory, String domainName,
			MicroserviceGeneratorRequest microServiceJsonPojo) {

		StringBuffer strBuff = new StringBuffer();

		addImportAndClassDeclarationForServiceImpl(domainName, strBuff);

		// getting command method info.
		ArrayList<ApiContract> commandArray = microServiceJsonPojo.getApiContracts();
		System.out.println("commandArray: " + commandArray);

		// getting queries method info.
	//	ArrayList<Query1> queriesArray = microServiceJsonPojo.getQueries();
		//System.out.println("queriesArray: " + queriesArray);

		// generate command methods
		generateCommandMethodsForServiceImpl(commandArray, strBuff, domainName);

		// generate quert methods
		//generateQueryMethodsForServiceImpl(queriesArray, strBuff, domainName);

		strBuff.append("\n");
		strBuff.append("}");
		System.out.println(strBuff.toString());

		// String controllerFileName =
		// "C:\\Gnana\\kubernetes_learning\\maven_archetype\\dir_mvn_generation\\" +
		// domainName
		// + "Controller.java";

		String controllerFileLocation = outputDirectory + domainName + File.separator + "src" + File.separator + "main"
				+ File.separator + "java" + File.separator + "com" + File.separator + "domain" + File.separator
				+ domainName + File.separator + "service" + File.separator + domainName + "ServiceImpl.java";

		Utility.writeToJavaFile(strBuff, controllerFileLocation);

	}

	private void addImportAndClassDeclarationForServiceImpl(String domainName, StringBuffer strBuff) {
		strBuff.append("package com.domain." + domainName + "." + "service;");
		strBuff.append("\n\n");

		strBuff.append("import com.domain." + domainName + ".model." + domainName + ";");
		strBuff.append("\n");

		strBuff.append("import com.domain." + domainName + ".repository." + domainName + "Repository;");
		strBuff.append("\n");

		strBuff.append("public class " + domainName + "ServiceImpl" + " implements " + domainName + "Service" + " {");
		strBuff.append("\n\n");

		strBuff.append("\tprivate " + domainName + "Repository objectRepository;");
		strBuff.append("\n\n");
	}

	private void generateCommandMethodsForServiceImpl(ArrayList<ApiContract> commandArray, StringBuffer strBuff,
			String domainName) {

		Iterator<ApiContract> commandAndQueryIterator = commandArray.iterator();
		StringBuffer methodParamsStringBuffer = null;

		while (commandAndQueryIterator.hasNext()) {

			methodParamsStringBuffer = new StringBuffer();

			ApiContract commandJsonObject = (ApiContract) commandAndQueryIterator.next();
			System.out.println(commandJsonObject);

			String methodName = (String) commandJsonObject.getMethodName();
			System.out.println("methodName ::" + methodName);

			// String methodAnnotation = generateAnnotations(methodName, domainName);

			ArrayList<Parameter> parametersArray = commandJsonObject.getParameters();
			Iterator<Parameter> parametersIterator = parametersArray.iterator();
			while (parametersIterator.hasNext()) {

				Parameter parameterJsonObject = parametersIterator.next();
				String paramType = (String) parameterJsonObject.getType();
				String paramName = (String) parameterJsonObject.getName();

				System.out.println(paramType + " " + paramName);
				methodParamsStringBuffer.append(paramType + " " + paramName);

				if (parametersIterator.hasNext()) {
					methodParamsStringBuffer.append(",");
				}

			}

			String returnType = "";
			String returnName = "";

			if (commandJsonObject.getReturnVal() != null) {

				ReturnVal returnObject = commandJsonObject.getReturnVal();

				returnType = (String) returnObject.getType();
				returnName = (String) returnObject.getName();

			}

			System.out.println("returnType :: " + returnType + " " + returnName);

			if (commandJsonObject.getReturnVal() == null) {

				strBuff.append("\tpublic " + "void" + " " + methodName + "(");
				strBuff.append(methodParamsStringBuffer.toString());

				strBuff.append("){");
				strBuff.append("\n\n");
			} else {

				strBuff.append("\tpublic " + returnType + " " + methodName + "(");
				strBuff.append(methodParamsStringBuffer.toString());

				strBuff.append("){");
				strBuff.append("\n\n");

				strBuff.append("\t" + returnType + " " + returnName + " = null;");

			}

			if (methodName.contains("add") || methodName.contains("save") || methodName.contains("update")) {
				strBuff.append("\n");
				strBuff.append("\t//objectRepository.save();");
				strBuff.append("\n");

			} else if (methodName.contains("delete")) {
				strBuff.append("\n");
				strBuff.append("\t//objectRepository.deleteById();");
				strBuff.append("\n\n");
			} else if (methodName.contains("find") || methodName.contains("get")) {
				strBuff.append("\n");
				strBuff.append("\t//objectRepository.findById();");
				strBuff.append("\n");
			}

			if (commandJsonObject.getReturnVal() != null) {

				strBuff.append("\n\treturn " + returnName + ";");
				strBuff.append("\n");
			}

			strBuff.append("\t}\n\n");

		}
	}

	/*
	private void generateQueryMethodsForServiceImpl(ArrayList<Query1> queryArray, StringBuffer strBuff,
			String domainName) {
		Iterator<Query1> queryIterator = queryArray.iterator();
		StringBuffer methodParamsStringBuffer = null;
		while (queryIterator.hasNext()) {

			methodParamsStringBuffer = new StringBuffer();

			Query1 queryJsonObject = queryIterator.next();
			System.out.println(queryJsonObject);

			String methodName = (String) queryJsonObject.getMethodName();
			System.out.println("methodName ::" + methodName);

			// String methodAnnotation = generateAnnotations(methodName, domainName);

			ArrayList<Parameter> parametersArray = queryJsonObject.getParameters();
			Iterator<Parameter> parametersIterator = parametersArray.iterator();
			while (parametersIterator.hasNext()) {

				Parameter parameterJsonObject = parametersIterator.next();
				String paramType = (String) parameterJsonObject.getType();
				String paramName = (String) parameterJsonObject.getName();

				System.out.println(paramType + " " + paramName);
				methodParamsStringBuffer.append(paramType + " " + paramName);

				if (parametersIterator.hasNext()) {
					methodParamsStringBuffer.append(",");
				}

			}

			String returnType = "";
			String returnName = "";

			if (queryJsonObject.getReturnVal() != null) {

				ReturnVal returnObject = queryJsonObject.getReturnVal();

				returnType = (String) returnObject.getType();
				returnName = (String) returnObject.getName();

			}

			System.out.println("returnType :: " + returnType + " " + returnName);

			if (queryJsonObject.getReturnVal() == null) {

				strBuff.append("\tpublic " + "void" + " " + methodName + "(");
				strBuff.append(methodParamsStringBuffer.toString());

				strBuff.append("){");
				strBuff.append("\n\n");
			} else {

				strBuff.append("\tpublic " + returnType + " " + methodName + "(");
				strBuff.append(methodParamsStringBuffer.toString());

				strBuff.append("){");
				strBuff.append("\n\n");

				strBuff.append("\t" + returnType + " " + returnName + " = null;");

			}

			if (methodName.contains("add") || methodName.contains("save") || methodName.contains("update")) {
				strBuff.append("\n");
				strBuff.append("\t//objectRepository.save();");
				strBuff.append("\n");

			} else if (methodName.contains("delete")) {
				strBuff.append("\n");
				strBuff.append("\t//objectRepository.deleteById();");
				strBuff.append("\n\n");
			} else if (methodName.contains("find") || methodName.contains("get")) {
				strBuff.append("\n");
				strBuff.append("\t//objectRepository.findById();");
				strBuff.append("\n");
			}

			if (queryJsonObject.getReturnVal() != null) {

				strBuff.append("\n\treturn " + returnName + ";");
				strBuff.append("\n");
			}

			strBuff.append("\t}\n\n");

		}
	}
	*/

}
