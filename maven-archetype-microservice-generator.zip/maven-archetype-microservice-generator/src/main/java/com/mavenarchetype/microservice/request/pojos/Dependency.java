package com.mavenarchetype.microservice.request.pojos;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Dependency {

	public String componentName;
	@JsonProperty("SQL")

	public String sQL;
	public String methodName;
	public ArrayList<Parameter> parameters;
	public ArrayList<ReturnVal> returnVal;
}