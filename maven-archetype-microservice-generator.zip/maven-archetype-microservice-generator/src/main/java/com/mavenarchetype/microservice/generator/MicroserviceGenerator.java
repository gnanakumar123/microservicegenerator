package com.mavenarchetype.microservice.generator;

import java.io.File;
import java.util.Collections;
import java.util.Properties;

import org.apache.maven.shared.invoker.DefaultInvocationRequest;
import org.apache.maven.shared.invoker.DefaultInvoker;
import org.apache.maven.shared.invoker.InvocationRequest;
import org.apache.maven.shared.invoker.InvocationResult;
import org.apache.maven.shared.invoker.Invoker;
import org.apache.maven.shared.invoker.MavenInvocationException;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mavenarchetype.microservice.request.pojos.MicroserviceGeneratorRequest;
import com.mavenarchetype.microservice.response.pojos.MicroserviceGeneratorResponse;

import ch.qos.logback.classic.Logger;

// Submit a POST request using below url
// http://localhost:8080/scaffolding/generateMicroService
// Send the request json in body

@RestController
@RequestMapping(path = "/scaffolding")
public class MicroserviceGenerator {

	Logger logger = (Logger) LoggerFactory.getLogger(MicroserviceGenerator.class);

	@Autowired
	RESTControllerGenerator rESTControllerGenerator;

	@Autowired
	ServiceInterfaceGenerator serviceInterfaceGenerator;

	@Autowired
	ServiceImplGenerator serviceImplGenerator;

	@PostMapping(path = "/generateMicroService", consumes = "application/json", produces = "application/json")
	public MicroserviceGeneratorResponse execute(@RequestBody MicroserviceGeneratorRequest microServiceJsonPojo)
			throws MavenInvocationException {

		// String outputDirectory =
		// "C:\\Gnana\\kubernetes_learning\\maven_archetype\\dir_mvn_generation";
		MicroserviceGeneratorResponse microserviceGeneratorResponse = new MicroserviceGeneratorResponse();
		String domainName = null;

		try {

			System.out.println("MicroServiceJsonPojo ::" + microServiceJsonPojo.toString());

			// Print Json
			printPostJsonBody(microServiceJsonPojo);

			InvocationRequest request = new DefaultInvocationRequest();
			request.setGoals(Collections.singletonList("archetype:generate"));

			// Interactive as FALSE
			request.setInteractive(false);

			domainName = microServiceJsonPojo.getDomainName();
			System.out.println("domainName ::" + domainName);

			String outputDirectory = microServiceJsonPojo.getOutputDirectory();

			System.out.println("outputDirectory ::" + outputDirectory);

			Properties properties = setProperties("com.domain." + domainName, domainName, "1.0.0-SNAPSHOT",
					outputDirectory);

			request.setProperties(properties);
			Invoker invoker = new DefaultInvoker();

			System.out.println("MAVEN_HOME ::" + System.getenv("MAVEN_HOME"));

			invoker.setMavenHome(new File(System.getenv("MAVEN_HOME")));
			InvocationResult result = invoker.execute(request);

			System.out.println("Generate Controller Class for domain :: Begin - " + domainName);
			rESTControllerGenerator.generateControllerForDomain(outputDirectory, domainName, microServiceJsonPojo);
			System.out.println("Generate Controller Class for domain :: End - " + domainName);

			System.out.println("Generate Service Interface for domain :: Begin - " + domainName);
			serviceInterfaceGenerator.generateServiceInterfaceForDomain(outputDirectory, domainName,
					microServiceJsonPojo);
			System.out.println("Generate Service Interface for domain :: End - " + domainName);

			System.out.println("Generate Service Impl for domain :: Begin - " + domainName);
			serviceImplGenerator.generateServiceImplForDomain(outputDirectory, domainName, microServiceJsonPojo);
			System.out.println("Generate Service Impl for domain :: End - " + domainName);

		} catch (Exception e) {
			microserviceGeneratorResponse.setErrorMessage("Error occurred during Microservice Generation for domain ::"
					+ domainName + " - Exception message " + e.getMessage());

			return microserviceGeneratorResponse;
		}

		microserviceGeneratorResponse
				.setSuccessMessage("Maven project generated successfully for domain ::" + domainName);

		return microserviceGeneratorResponse;
	}

	private void printPostJsonBody(MicroserviceGeneratorRequest microServiceJsonPojo) {
		ObjectMapper mapper = new ObjectMapper();
		try {
			String json = mapper.writeValueAsString(microServiceJsonPojo);
			System.out.println("POST API Request :: JSON = " + json);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
	}

	private Properties setProperties(String groupId, String artifactId, String version, String outputDirectory) {
		Properties properties = new Properties();

		// This is the package structure
		properties.setProperty("groupId", groupId);
		// This is also the package structure
		properties.setProperty("package", groupId);

		// This is the Spring Boot Project name
		properties.setProperty("artifactId", artifactId);
		// This is also the Spring Boot Project name
		properties.setProperty("project-name", artifactId);

		properties.setProperty("version", version);

		properties.setProperty("archetypeGroupId", "com.gk.custom.mvnarchetype");
		properties.setProperty("archetypeArtifactId", "gk-custom-mvnarchetype");
		properties.setProperty("outputDirectory", outputDirectory);
		// properties.setProperty("archetypeVersion", "1.1");

		// For webapp, use "maven-archetype-webapp"

		// properties.setProperty("archetypeCatalog",
		// "https://repo.maven.apache.org/maven2/archetype-catalog.xml");
		return properties;
	}

}