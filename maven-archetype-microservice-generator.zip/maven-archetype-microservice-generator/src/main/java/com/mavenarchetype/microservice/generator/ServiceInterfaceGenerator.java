package com.mavenarchetype.microservice.generator;

import java.util.ArrayList;
import java.util.Iterator;

import org.springframework.stereotype.Component;

import com.mavenarchetype.microservice.request.pojos.Command;
import com.mavenarchetype.microservice.request.pojos.MicroserviceGeneratorRequest;
import com.mavenarchetype.microservice.request.pojos.Parameter;
import com.mavenarchetype.microservice.request.pojos.Query;
import com.mavenarchetype.microservice.request.pojos.ReturnVal;
import com.mavenarchetype.microservice.utility.Utility;



@Component
public class ServiceInterfaceGenerator {

	public void generateServiceInterfaceForDomain(String outputDirectory, String domainName,
			MicroserviceGeneratorRequest microServiceJsonPojo) {

		StringBuffer strBuff = new StringBuffer();

		addImportAndClassDeclarationForServiceInterface(domainName, strBuff);

		// getting command method info.
		ArrayList<Command> commandArray = microServiceJsonPojo.getCommands();
		System.out.println("commandArray: " + commandArray);

		// getting queries method info.
		ArrayList<Query> queriesArray = microServiceJsonPojo.getQueries();
		System.out.println("queriesArray: " + queriesArray);

		// generate command methods
		generateCommandMethodsForServiceInterface(commandArray, strBuff, domainName);

		// generate query methods
		generateQueryMethodsForServiceInterface(queriesArray, strBuff, domainName);

		strBuff.append("\n");
		strBuff.append("}");
		System.out.println(strBuff.toString());

		// String controllerFileName =
		// "C:\\Gnana\\kubernetes_learning\\maven_archetype\\dir_mvn_generation\\" +
		// domainName
		// + "Controller.java";

		String controllerFileLocation = outputDirectory + domainName + "\\" + "src\\main\\java\\com\\domain\\"
				+ domainName + "\\" + "service\\" + domainName + "Service.java";

		Utility.writeToJavaFile(strBuff, controllerFileLocation);

	}

	private void addImportAndClassDeclarationForServiceInterface(String domainName, StringBuffer strBuff) {
		strBuff.append("package com.domain." + domainName + "." + "service;");
		strBuff.append("\n\n");

		strBuff.append("import com.domain." + domainName + ".model." + domainName + ";");
		strBuff.append("\n");

		strBuff.append("public interface " + domainName + "Service {");
		strBuff.append("\n\n");
	}

	private void generateCommandMethodsForServiceInterface(ArrayList<Command> commandArray, StringBuffer strBuff,
			String domainName) {
		Iterator<Command> commandIterator = commandArray.iterator();
		StringBuffer methodParamsStringBuffer = null;
		while (commandIterator.hasNext()) {

			methodParamsStringBuffer = new StringBuffer();

			Command commandJsonObject = commandIterator.next();
			System.out.println(commandJsonObject);

			String methodName = (String) commandJsonObject.getMethodName();
			System.out.println("methodName ::" + methodName);

			// String methodAnnotation = generateAnnotations(methodName, domainName);

			ArrayList<Parameter> parametersArray = commandJsonObject.getParameters();
			Iterator<Parameter> parametersIterator = parametersArray.iterator();
			while (parametersIterator.hasNext()) {

				Parameter parameterJsonObject = parametersIterator.next();
				String paramType = (String) parameterJsonObject.getType();
				String paramName = (String) parameterJsonObject.getName();

				System.out.println(paramType + " " + paramName);

				methodParamsStringBuffer.append(paramType + " " + paramName);
				if (parametersIterator.hasNext()) {
					methodParamsStringBuffer.append(",");
				}

			}

			String returnType = "";
			String returnName = "";

			if (commandJsonObject.getReturnVal() != null) {

				ReturnVal returnObject = commandJsonObject.getReturnVal();

				returnType = (String) returnObject.getType();
				returnName = (String) returnObject.getName();

			}

			System.out.println("returnType :: " + returnType + " " + returnName);

			if (commandJsonObject.getReturnVal() == null) {

				strBuff.append("\tpublic " + "void" + " " + methodName + "(");
				strBuff.append(methodParamsStringBuffer.toString());

				strBuff.append(");");
				strBuff.append("\n\n");
			} else {

				strBuff.append("\tpublic " + returnType + " " + methodName + "(");
				strBuff.append(methodParamsStringBuffer.toString());

				strBuff.append(");");
				strBuff.append("\n\n");

			}

			strBuff.append("\n");

		}
	}

	private void generateQueryMethodsForServiceInterface(ArrayList<Query> queryArray, StringBuffer strBuff,
			String domainName) {

		Iterator<Query> queryIterator = queryArray.iterator();
		StringBuffer methodParamsStringBuffer = null;

		while (queryIterator.hasNext()) {

			methodParamsStringBuffer = new StringBuffer();

			Query queryJsonObject = queryIterator.next();
			System.out.println(queryJsonObject);

			String methodName = (String) queryJsonObject.getMethodName();
			System.out.println("methodName ::" + methodName);

			// String methodAnnotation = generateAnnotations(methodName, domainName);

			ArrayList<Parameter> parametersArray = queryJsonObject.getParameters();
			Iterator<Parameter> parametersIterator = parametersArray.iterator();
			while (parametersIterator.hasNext()) {

				Parameter parameterJsonObject = parametersIterator.next();
				String paramType = (String) parameterJsonObject.getType();
				String paramName = (String) parameterJsonObject.getName();

				System.out.println(paramType + " " + paramName);

				methodParamsStringBuffer.append(paramType + " " + paramName);
				if (parametersIterator.hasNext()) {
					methodParamsStringBuffer.append(",");
				}

			}

			String returnType = "";
			String returnName = "";

			if (queryJsonObject.getReturnVal() != null) {

				ReturnVal returnObject = queryJsonObject.getReturnVal();

				returnType = (String) returnObject.getType();
				returnName = (String) returnObject.getName();

			}

			System.out.println("returnType :: " + returnType + " " + returnName);

			if (queryJsonObject.getReturnVal() == null) {

				strBuff.append("\tpublic " + "void" + " " + methodName + "(");
				strBuff.append(methodParamsStringBuffer.toString());

				strBuff.append(");");
				strBuff.append("\n\n");
			} else {

				strBuff.append("\tpublic " + returnType + " " + methodName + "(");
				strBuff.append(methodParamsStringBuffer.toString());

				strBuff.append(");");
				strBuff.append("\n\n");

			}

			strBuff.append("\n");

		}
	}

}
