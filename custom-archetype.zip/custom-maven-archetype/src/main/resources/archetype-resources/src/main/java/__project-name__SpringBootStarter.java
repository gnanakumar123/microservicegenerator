package ${package};
 

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ${project-name}SpringBootStarter {

	public static void main(String[] args) {
		SpringApplication.run(${project-name}SpringBootStarter.class, args);
	}
}
