package ${package}.service;

import java.util.List;

import ${package}.model.${project-name};

public interface ${project-name}WrapperService {

	public List<${project-name}> findAll();
	
	public ${project-name} findById(int theId);
	
	public void save(${project-name} object);
	
	public void update(${project-name} object);
	
	public void deleteById(int theId);
	
}
