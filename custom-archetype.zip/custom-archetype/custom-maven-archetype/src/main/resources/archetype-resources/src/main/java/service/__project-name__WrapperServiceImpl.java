package ${package}.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ${package}.repository.${project-name}Repository;
import ${package}.model.${project-name};

@Service
public class ${project-name}WrapperServiceImpl implements ${project-name}WrapperService {

	private ${project-name}Repository objectRepository;
	
	@Autowired
	public ${project-name}WrapperServiceImpl(${project-name}Repository the${project-name}Repository) {
		objectRepository = the${project-name}Repository;
	}
	
	@Override
	public List<${project-name}> findAll() {
		return objectRepository.findAll();
	}

	@Override
	public ${project-name} findById(int theId) {
		Optional<${project-name}> result = objectRepository.findById(theId);
		
		${project-name} the${project-name} = null;
		
		if (result.isPresent()) {
			the${project-name} = result.get();
		}
		else {
			// we didn't find the object
			throw new RuntimeException("Did not find employee id - " + theId);
		}
		
		return the${project-name};
	}

	@Override
	public void save(${project-name} the${project-name}) {
		objectRepository.save(the${project-name});
	}
	
	@Override
	public void update(${project-name} the${project-name}) {
		objectRepository.save(the${project-name});
	}

	@Override
	public void deleteById(int theId) {
		objectRepository.deleteById(theId);
	}

}






