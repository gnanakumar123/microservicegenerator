package ${package}.controller;
 

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ${package}.model.${project-name};
import ${package}.service.${project-name}WrapperServiceImpl;

@RestController
@RequestMapping("/api")
public class ${project-name}WrapperController {

	@Autowired
	private ${project-name}WrapperServiceImpl service;
	
	
	// expose "/${project-name}" and return list of ${project-name}
	@GetMapping("/${project-name}")
	public List<${project-name}> findAll() {
		return service.findAll();
	}

	// add mapping for GET /${project-name}/{Id}	
	@GetMapping("/${project-name}/{Id}")
	public ${project-name} get${project-name}(@PathVariable int objectId) {
		
		${project-name} object = service.findById(objectId);
		
		if (object == null) {
			throw new RuntimeException("${project-name} id not found - " + objectId);
		}
		
		return object;
	}
	
	// add mapping for POST /${project-name} - add new ${project-name}	
	@PostMapping("/${project-name}")
	public ${project-name} add${project-name}(@RequestBody ${project-name} object) {
		
		// also just in case they pass an id in JSON ... set id to 0
		// this is to force a save of new item ... instead of update
		
		object.setId(0);
		
		service.save(object);
		
		return object;
	}
	
	// add mapping for PUT /${project-name} - update existing ${project-name}	
	@PutMapping("/${project-name}")
	public ${project-name} update${project-name}(@RequestBody ${project-name} object) {
		
		service.save(object);
		
		return object;
	}
	
	// add mapping for DELETE /${project-name}/{Id} - delete ${project-name}	
	@DeleteMapping("/${project-name}/{Id}")
	public String delete${project-name}(@PathVariable int objectId) {
		
		${project-name} tempObject = service.findById(objectId);
		
		// throw exception if null		
		if (tempObject == null) {
			throw new RuntimeException("${project-name} id not found - " + objectId);
		}
		
		service.deleteById(objectId);
		
		return "Deleted object id - " + objectId;
	}
	
}


