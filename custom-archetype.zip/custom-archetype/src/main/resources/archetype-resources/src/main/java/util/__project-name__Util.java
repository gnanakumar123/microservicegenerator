package ${package}.util;

public class ${project-name}Util {

}