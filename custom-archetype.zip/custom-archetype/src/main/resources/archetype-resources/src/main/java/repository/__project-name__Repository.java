package ${package}.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import ${package}.model.${project-name};

public interface ${project-name}Repository extends JpaRepository<${project-name}, Integer> {

	
	
}
